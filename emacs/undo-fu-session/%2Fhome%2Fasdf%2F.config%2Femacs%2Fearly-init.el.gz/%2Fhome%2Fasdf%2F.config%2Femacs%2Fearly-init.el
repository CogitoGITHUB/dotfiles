((buffer-size . 516) (buffer-checksum . "88d0d20ff61fa261140520a727d00cbdd901c16a"))
((emacs-buffer-undo-list nil (";; Remove *all* chrome before frames appear
" . 30) ((marker* . 30) . 44) ((marker . 30) . -43) ((marker) . -44) nil ("
;; Silence startup clutter
(setq inhibit-startup-message t
      inhibit-startup-echo-area-message t
      use-dialog-box nil
      frame-inhibit-implied-resize t
      package-enable-at-startup nil)

" . 30) ((marker . 30) . -201) ((marker . 30) . -201) ((marker . 30) . -201) ((marker . 30) . -201) ((marker . 30) . -201) ((marker) . -202) ((marker) . -202) ((marker . 30) . -201) (t 26917 51851 365280 971000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))